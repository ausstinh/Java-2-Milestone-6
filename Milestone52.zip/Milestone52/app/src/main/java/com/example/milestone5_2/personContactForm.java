package com.example.milestone5_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.milestone5_2.model.AddressBook;
import com.example.milestone5_2.model.PersonContact;

public class personContactForm extends AppCompatActivity {
    ImageView iv_back, iv_delete, iv_edit;
    TextView tv_name, tv_address, tv_phone, tv_city, tv_state, tv_zipCode, tv_country, tv_email, tv_description;
    AddressBook addressBook;
    PersonAdapter adapter;
    int positionnumber = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.person_contact);

        tv_name = findViewById(R.id.tv_name);
        tv_address = findViewById(R.id.tv_address);
        tv_city = findViewById(R.id.tv_city);
        tv_state = findViewById(R.id.tv_state);
        tv_zipCode = findViewById(R.id.tv_zipCode);
        tv_phone = findViewById(R.id.tv_phone);
        tv_country = findViewById(R.id.tv_country);
        tv_email = findViewById(R.id.tv_email);
        tv_description = findViewById(R.id.tv_description);

        Bundle incomingIntent = getIntent().getExtras();

        addressBook = ((MyApplication) this.getApplication()).getAddressBook();
        adapter = new PersonAdapter(personContactForm.this, addressBook);
        if (incomingIntent != null) {

            positionnumber = incomingIntent.getInt("indexNumber");

           // Log.d("austinsapp", "persontoshow = " + positionnumber);
           // Log.d("austinsapp", "addressbook = " + addressBook.toString());


        }
        else
            positionnumber = -1;



        if(positionnumber == -1){
            return;
        }
        PersonContact p = (PersonContact) addressBook.getTheList().get(positionnumber);


        tv_name.setText(p.getName());
        tv_address.setText(p.getStreet());
        tv_city.setText(p.getCity());
        tv_state.setText(p.getState());
        tv_zipCode.setText(p.getZip());
        tv_phone.setText(p.getPhoneNumber());
        tv_country.setText(p.getCountry());
        tv_email.setText(p.getEmail());
        tv_description.setText(p.getDescription());


        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), search.class);
                startActivity(i);
            }
        });

        iv_delete = findViewById(R.id.iv_delete);
        iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), deletePerson.class);
                i.putExtra("contactIndex", positionnumber);
                startActivity(i);
            }
        });

        iv_edit = findViewById(R.id.iv_edit);
        iv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v ){
                Intent i = new Intent(getApplicationContext(), EditPerson.class);

                //get the contents of person at position
                PersonContact p = addressBook.getPersonList().get(positionnumber);




                i.putExtra("name", p.getName());
                i.putExtra("phonenumber", p.getPhoneNumber().toString());
                i.putExtra("address", p.getStreet());
                i.putExtra("city", p.getCity());
                i.putExtra("state", p.getState());
                i.putExtra("photo", p.getPhoto());
                i.putExtra("zipcode", p.getZip().toString());
                i.putExtra("country", p.getCountry());
                i.putExtra("email", p.getEmail());
                i.putExtra("description", p.getDescription());
                i.putExtra("edit", positionnumber);




                startActivity(i);

            }
        });
    }


}