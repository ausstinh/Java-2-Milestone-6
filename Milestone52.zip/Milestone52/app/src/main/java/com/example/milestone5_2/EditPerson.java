package com.example.milestone5_2;

import android.app.AppComponentFactory;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import com.example.milestone5_2.BorP;
import com.example.milestone5_2.Home;
import com.example.milestone5_2.MyApplication;
import com.example.milestone5_2.PersonAdapter;
import com.example.milestone5_2.R;
import com.example.milestone5_2.model.AddressBook;
import com.example.milestone5_2.model.PersonContact;
import com.example.milestone5_2.newPerson;
import com.example.milestone5_2.photo;


public class EditPerson extends AppCompatActivity {

    ImageView iv_back, iv_pic;
    Button btn_add;
    EditText et_name, et_phone, et_address, et_city, et_state, et_zipCode, et_country, et_email, et_description;
    ImageView iv_photo;
    int positionToEdit = -1;

    AddressBook addressBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit);

        et_name = findViewById(R.id.tv_name);
        et_phone = findViewById(R.id.et_phone);
        et_address = findViewById(R.id.tv_address);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        et_zipCode = findViewById(R.id.tv_zipCode);
        et_country = findViewById(R.id.et_country);
        et_email = findViewById(R.id.et_email);
        et_description = findViewById(R.id.et_description);


        // get values from global variable in myapplication
        addressBook = ((MyApplication) getApplication()).getAddressBook();




        Bundle incomingIntent = getIntent().getExtras();

        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            String phone = incomingIntent.getString("phonenumber");
            String address = incomingIntent.getString("address");
            String city = incomingIntent.getString("city");
            String state = incomingIntent.getString("state");
            String zipString =  incomingIntent.getString("zipcode");
            String country = incomingIntent.getString("country");
            String email = incomingIntent.getString("email");
            String description = incomingIntent.getString("description");
            positionToEdit = incomingIntent.getInt("edit");

            Log.d("austinsapp",zipString);
            //Log.d("austinsapp", " incomping text" + incomingIntent.getInt("zipcode"));

            et_name.setText(name);
            et_phone.setText(phone);
            et_address.setText(address);
            et_city.setText(city);
            et_state.setText(state);
            et_zipCode.setText(zipString);
            et_country.setText(country);
            et_email.setText(email);
            et_description.setText(description);


        }

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), BorP.class);
                startActivity(i);
            }
        });

        iv_pic = findViewById(R.id.iv_photo);
        iv_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), photo.class);
                startActivity(i);
            }
        });

        btn_add = findViewById(R.id.btn_add);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                String newName = et_name.getText().toString();
                String newPhone = et_phone.getText().toString();
                String newAddress = et_address.getText().toString();
                String newCity = et_city.getText().toString();
                String newState = et_state.getText().toString();
                String newZipCode = et_zipCode.getText().toString();
                String newCountry = et_country.getText().toString();
                String newEmail = et_email.getText().toString();
                String newDescription = et_description.getText().toString();

                PersonContact p = new PersonContact(newName, newAddress, newCity, newState, "image.jpg", newZipCode, newCountry,newPhone, newEmail, newDescription);


                Intent mIntent = getIntent();
                int intValue = mIntent.getIntExtra("contactIndex", 0);

                addressBook.deleteContact(addressBook.getTheList().get(intValue));
                addressBook.getTheList().add(p);

               // Log.d("","edit complete", addressBook.toString());
                // intent to return to main activity






                Intent i = new Intent(v.getContext(), Home.class);



                startActivity(i);
            }
        });



    }
}
