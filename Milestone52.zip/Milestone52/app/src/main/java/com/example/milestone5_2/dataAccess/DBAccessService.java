package com.example.milestone5_2.dataAccess;

public class DBAccessService {

	/*@Override
	public BusinessService readAllData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean writeAllData(AddressBook contactApp) {
		// TODO Auto-generated method stub
		return false;
	}*/

}
