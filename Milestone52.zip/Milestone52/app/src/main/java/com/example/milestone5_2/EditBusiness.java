package com.example.milestone5_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.milestone5_2.model.AddressBook;
import com.example.milestone5_2.model.BusinessContact;

public class EditBusiness extends AppCompatActivity {

    ImageView iv_back, iv_pic;
    Button btn_add;
    EditText et_name, et_phone, et_address, et_city, et_state, et_zipCode, et_country, et_opening, et_closing, et_URL;
    ImageView iv_photo;
    int positionToEdit = -1;

    PersonAdapter adapter;

    AddressBook addressBook;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_business);

        et_name = findViewById(R.id.et_name);
        et_phone = findViewById(R.id.et_phone);
        et_address = findViewById(R.id.et_address);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        et_zipCode = findViewById(R.id.et_zipCode);
        et_country = findViewById(R.id.et_country);
        et_opening = findViewById(R.id.et_opening);
        et_closing = findViewById(R.id.et_closing);
        et_URL = findViewById(R.id.et_URL);

        addressBook = ((MyApplication) getApplication()).getAddressBook();




        Bundle incomingIntent = getIntent().getExtras();

        if (incomingIntent != null) {
            String name = incomingIntent.getString("name");
            String phone = incomingIntent.getString("phonenumber");
            final String address = incomingIntent.getString("address");
            String city = incomingIntent.getString("city");
            String state = incomingIntent.getString("state");
            String zipCode = incomingIntent.getString("zipcode");
            String country = incomingIntent.getString("country");
            String opening = incomingIntent.getString("opening");
            String closing = incomingIntent.getString("closing");
            String URL = incomingIntent.getString("URL");
            positionToEdit = incomingIntent.getInt("edit");

            et_name.setText(name);
            et_phone.setText(phone);
            et_address.setText(address);
            et_city.setText(city);
            et_state.setText(state);
            et_zipCode.setText(zipCode);
            et_country.setText(country);
            et_opening.setText(opening);
            et_closing.setText(closing);
            et_URL.setText(URL);

            iv_back = findViewById(R.id.iv_back);
            iv_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), BorP.class);
                    startActivity(i);
                }
            });

            iv_pic = findViewById(R.id.iv_photo);
            iv_pic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), photo.class);
                    startActivity(i);
                }
            });

            btn_add = findViewById(R.id.btn_add);
            btn_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String newName = et_name.getText().toString();
                    String newPhone = et_phone.getText().toString();
                    String newAddress = et_address.getText().toString();
                    String newCity = et_city.getText().toString();
                    String newState = et_state.getText().toString();
                    String newZipCode = et_zipCode.getText().toString();
                    String newCountry = et_country.getText().toString();
                    String newOpeing = et_opening.getText().toString();
                    String newClosing = et_closing.getText().toString();
                    String newURL = et_URL.getText().toString();

                    BusinessContact b = new BusinessContact(newName, newPhone, newAddress, newCity, newState, "img.jpg",
                            newZipCode, newCountry, newOpeing, newClosing, newURL );

                    Intent mIntent = getIntent();
                    int intValue = mIntent.getIntExtra("contactIndex", 0);







                    addressBook.deleteContact(addressBook.getTheList().get(intValue));
                    addressBook.getTheList().add(b);


                    Intent i = new Intent(v.getContext(), Home.class);

                    i.putExtra("edit", positionToEdit);
                    i.putExtra("name", newName);
                    i.putExtra("address", newAddress);
                    i.putExtra("city", newCity);
                    i.putExtra("state", newState);
                    i.putExtra("zipCode", newZipCode);
                    i.putExtra("country", newCountry);
                    i.putExtra("phone", newPhone);
                    i.putExtra("opening", newOpeing);
                    i.putExtra("closing", newClosing);
                    i.putExtra("URL", newURL);

                    startActivity(i);
                }
            });


        }

    }

}