package com.example.milestone5_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.milestone5_2.model.AddressBook;
import com.example.milestone5_2.model.BusinessContact;

public class businessContactForm extends AppCompatActivity {

    ImageView iv_back, iv_delete, iv_edit;
    AddressBook addressBook;
    TextView tv_name, tv_address, tv_phone, tv_city, tv_state, tv_zipCode, tv_country, tv_am, tv_pm, tv_URL;
    int positionnumber = -1;
    PersonAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_contact);
        addressBook = ((MyApplication) this.getApplication()).getAddressBook();
        adapter = new PersonAdapter(businessContactForm.this, addressBook);


        tv_name = findViewById(R.id.tv_name);
        tv_address = findViewById(R.id.tv_address);
        tv_city = findViewById(R.id.tv_city);
        tv_state = findViewById(R.id.tv_state);
        tv_zipCode = findViewById(R.id.tv_zipCode);
        tv_phone = findViewById(R.id.tv_phone);
        tv_country = findViewById(R.id.tv_country);
        tv_am = findViewById(R.id.tv_am);
        tv_pm = findViewById(R.id.tv_pm);
        tv_URL = findViewById(R.id.tv_description);

        Bundle incomingIntent = getIntent().getExtras();

        if (incomingIntent != null) {

            positionnumber = incomingIntent.getInt("indexNumber");

            // Log.d("austinsapp", "persontoshow = " + positionnumber);
            // Log.d("austinsapp", "addressbook = " + addressBook.toString());


        }
        else
            positionnumber = -1;



        if(positionnumber == -1){
            return;
        }


        BusinessContact b = (BusinessContact) addressBook.getTheList().get(positionnumber);


        tv_name.setText(b.getName());
        tv_address.setText(b.getStreet());
        tv_city.setText(b.getCity() + ", " + b.getState());
        tv_zipCode.setText(b.getZip());
        tv_phone.setText(b.getPhoneNumber());
        tv_country.setText(b.getCountry());
        tv_am.setText(b.getOpening());
        tv_pm.setText(b.getClosing());
        tv_URL.setText(b.getUrl());

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), search.class);
                startActivity(i);
            }
        });

        iv_delete = findViewById(R.id.iv_delete);
        iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), deleteBusiness.class);
                i.putExtra("contactIndex", positionnumber);
                startActivity(i);
            }
        });
        iv_edit = findViewById(R.id.iv_edit);
        iv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), EditBusiness.class);

                //get the contents of person at position
                BusinessContact b = addressBook.getBusinessList().get(positionnumber);




                i.putExtra("name", b.getName());
                i.putExtra("phonenumber", b.getPhoneNumber().toString());
                i.putExtra("address", b.getStreet());
                i.putExtra("city", b.getCity());
                i.putExtra("state", b.getState());
                i.putExtra("photo", b.getPhoto());
                i.putExtra("zipcode", b.getZip().toString());
                i.putExtra("country", b.getCountry());
                i.putExtra("opening", b.getOpening());
                i.putExtra("closing", b.getClosing());
                i.putExtra("URL", b.getUrl());
                i.putExtra("edit", positionnumber);




                startActivity(i);
            }
        });

    }

}
