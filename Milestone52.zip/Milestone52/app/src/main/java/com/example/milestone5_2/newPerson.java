package com.example.milestone5_2;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.milestone5_2.model.AddressBook;
import com.example.milestone5_2.model.PersonContact;

public class newPerson extends AppCompatActivity {

Context context;
    ImageView iv_back, iv_pic;
    Button btn_add;
    EditText et_name, et_phone, et_address, et_city, et_state, et_zipCode, et_country, et_email, et_description;
    ImageView iv_photo;
    int positionToEdit = -1;
    DataService dataService = new DataService(context);
    PersonAdapter adapter;

    AddressBook addressBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.person);

        et_name = findViewById(R.id.tv_name);
        et_phone = findViewById(R.id.et_phone);
        et_address = findViewById(R.id.tv_address);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        et_zipCode = findViewById(R.id.tv_zipCode);
        et_country = findViewById(R.id.et_country);
        et_email = findViewById(R.id.et_email);
        et_description = findViewById(R.id.et_description);


        // get values from global variable in myapplication
        addressBook = ((MyApplication) getApplication()).getAddressBook();

        adapter = new PersonAdapter(newPerson.this, addressBook);



        Bundle incomingIntent = getIntent().getExtras();

        if(incomingIntent != null){
            String name = incomingIntent.getString("name");
            int phone = incomingIntent.getInt("phonenumber");
            String address = incomingIntent.getString("address");
            String city = incomingIntent.getString("city");
            String state = incomingIntent.getString("state");
            int zipCode = incomingIntent.getInt("zipcode");
            String country = incomingIntent.getString("country");
            String email = incomingIntent.getString("email");
            String description = incomingIntent.getString("description");
            positionToEdit = incomingIntent.getInt("edit");

           et_name.setText(name);
           et_phone.setText(Integer.toString(phone));
           et_address.setText(address);
           et_city.setText(city);
           et_state.setText(state);
           et_zipCode.setText(Integer.toString(zipCode));
           et_country.setText(country);
           et_email.setText(email);
           et_description.setText(description);


        }

        iv_back = findViewById(R.id.iv_back);
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), BorP.class);
                startActivity(i);
            }
        });

        iv_pic = findViewById(R.id.iv_photo);
        iv_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), photo.class);
                startActivity(i);
            }
        });

        btn_add = findViewById(R.id.btn_add);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


        //takes inputs and defines properties
              String newName = et_name.getText().toString();
              String newPhone = et_phone.getText().toString();
              String newAddress = et_address.getText().toString();
              String newCity = et_city.getText().toString();
              String newState = et_state.getText().toString();
              String newZipCode = et_zipCode.getText().toString();
              String newCountry = et_country.getText().toString();
              String newEmail = et_email.getText().toString();
              String newDescription = et_description.getText().toString();

                PersonContact p = new PersonContact(newName, newAddress, newCity, newState, "image.jpg", newZipCode, newCountry,newPhone, newEmail, newDescription);



                addressBook.getPersonList().add(p);
                adapter.notifyDataSetChanged();





                addressBook.getTheList().add(p);
                adapter.notifyDataSetChanged();






                // intent to return to main activity
                Intent i = new Intent(v.getContext(), Home.class);

                i.putExtra("edit", positionToEdit);
                i.putExtra("name", newName);
                i.putExtra("address", newAddress);
                i.putExtra("city", newCity);
                i.putExtra("state", newState);
                i.putExtra("zipCode", newZipCode);
                i.putExtra("country", newCountry);
                i.putExtra("phone", newPhone);
                i.putExtra("email", newEmail);
                i.putExtra("description", newDescription);

                startActivity(i);
            }
        });


    }
}
